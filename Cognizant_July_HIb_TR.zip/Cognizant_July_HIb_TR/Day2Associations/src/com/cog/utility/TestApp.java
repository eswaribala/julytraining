package com.cog.utility;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.cog.dao.DaoManager;
import com.cog.entities.Address;
import com.cog.entities.Author;
import com.cog.entities.Book;
import com.cog.entities.Course;
import com.cog.entities.Customer;
import com.cog.entities.Player;
import com.cog.entities.Team;
import com.cog.entities.Trainee;

public class TestApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        DaoManager dao=new DaoManager();
        List<Trainee> traineeList=new ArrayList<Trainee>();
        List<Course> courseList=new ArrayList<Course>();
        Trainee trainee = new Trainee();
        trainee.setTraineeName("Sanjay");
        traineeList.add(trainee);
        trainee = new Trainee();
        trainee.setTraineeName("Sudha");
        traineeList.add(trainee);
        trainee = new Trainee();
        trainee.setTraineeName("Ananya");
        traineeList.add(trainee);
        Course course =new Course();
        course.setCourseName("Hibernate");
        course.setTraineeList(traineeList);
        courseList.add(course); 
        dao.AddTrainee_Course(traineeList, courseList);
        		
        
        
        
        
        
       /* for(Team team : dao.getAllTeam_Players())
        {
        	System.out.println(team.getName());
        	for(Player player : team.getPlayerList())
        	{
        		System.out.println(player.getPlayerName());
        	}
        }
        
        */
        
        
        
        
       /* Team team=new Team();
        team.setName("RC");
        List<Player> playerList=new ArrayList<Player>();
        Player player =new Player();
        player.setPlayerName("Chris Gail");
        player.setTeam(team);
        playerList.add(player);
        player =new Player();
        player.setPlayerName("Uthappa");
        player.setTeam(team);
        playerList.add(player);
        player =new Player();
        player.setPlayerName("Rahul");
        player.setTeam(team);
        playerList.add(player);
        dao.AddTeam_Player(team, playerList);*/
        
        
        
        
        
        
        
     /*   Book book =new Book();
        book.setBookName("Java");
        book.setDOP(new Date(97,1,1));
        Author author = new Author();
        author.setAuthorName("Gosling");
        dao.AddBook_Author(book, author);
        */
        
      /*  Iterator itr = dao.GetAll().iterate();
        System.out.println("CustomerId"+"\t"+"Name"+"\t"+"Street"+"\t"+"City");
        while(itr.hasNext())
        {
        	Object[] obj=(Object[]) itr.next();
        	System.out.println(obj[0] + "\t"+obj[1]+"\t"+obj[2]+"\t"+obj[3]);
        	
        }*/
        
       
        /*Address address=new Address();
        address.setStreet("Rajaji Street");
        address.setCity("Chennai");
        Customer customer=new Customer();
        customer.setName("Soma");
        customer.setDob(new Date(57,5,5));
       dao.AddCustomer_Address(customer, address);*/
		
	}

}
