package com.cog.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cog.entities.Address;
import com.cog.entities.Author;
import com.cog.entities.Book;
import com.cog.entities.Course;
import com.cog.entities.Customer;
import com.cog.entities.Player;
import com.cog.entities.Team;
import com.cog.entities.Trainee;
import com.cog.resources.HibernateUtil;

public class DaoManager {

	private SessionFactory factory;
	private Session session;
	private boolean status;
	
	public DaoManager()
	{
		factory=HibernateUtil.GetFactory();
	}
	
	public boolean AddCustomer_Address(Customer customer, Address address)
	{
		session=factory.openSession();
		session.beginTransaction();
		try
		{
			session.persist(address);
			customer.setAddress(address);
			session.persist(customer);
			session.getTransaction().commit();
			status=true;
			
		}
		catch(HibernateException hib)
		{
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}
	
	public Query GetAll()
	{
		session=factory.openSession();
		return session.createQuery("select cust.customerId,cust.name,addr.street,"
				+ "addr.city from Customer cust inner join cust.address addr");
	}
	
	public boolean AddBook_Author(Book book,Author author)
	{
		session=factory.openSession();
		session.beginTransaction();
		try
		{
		
			author.setBook(book);
			book.setAuthor(author);
			session.save(book);
			session.getTransaction().commit();
			status=true;
			
		}
		catch(HibernateException hib)
		{
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}
	public boolean AddTeam_Player(Team team, List<Player> playerList)
	{
		session=factory.openSession();
		session.beginTransaction();
		try
		{
		   team.setPlayerList(playerList);			
			session.save(team);
			session.getTransaction().commit();
			status=true;
			
		}
		catch(HibernateException hib)
		{
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}
	
	public List<Team> getAllTeam_Players()
	{
		session=factory.openSession();
		return session.createQuery("from Team").list();
	}
	
	public boolean AddTrainee_Course(List<Trainee> traineeList, List<Course> courseList)
	{
		session=factory.openSession();
		session.beginTransaction();
		try
		{
		 for(Trainee trainee:traineeList)
		 {
			 trainee.setCourseList(courseList);
			 session.save(trainee);
		 }
			
			
			session.getTransaction().commit();
			status=true;
			
		}
		catch(HibernateException hib)
		{
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}
	
	
	
}
