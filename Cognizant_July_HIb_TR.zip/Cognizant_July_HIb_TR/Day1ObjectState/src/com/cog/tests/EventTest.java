package com.cog.tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cog.dao.EventManager;
import com.cog.entities.Event;
import com.cog.entities.EventKey;

public class EventTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		EventManager eventmanager=new EventManager();
		EventKey eventkey =new EventKey();
		eventkey.setEventId(3);
		eventkey.setTrainerId(349);
		Event event =new Event();
		event.setEventid(eventkey);
		event.setDuration(5);
		event.setLocation("Chennai");
		event.setEventName("REST Training");
	  assertTrue(	eventmanager.AddEvent(event));
		
	}

}
