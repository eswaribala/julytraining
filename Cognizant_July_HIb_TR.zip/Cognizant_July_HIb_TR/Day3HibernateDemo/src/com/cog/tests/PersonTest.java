package com.cog.tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cog.dao.DaoManager;
import com.cog.entities.Address;
import com.cog.entities.Manager;
import com.cog.entities.Person;

public class PersonTest {
private DaoManager dao;
	@Before
	public void setUp() throws Exception {
		dao=new DaoManager();
	}

	@After
	public void tearDown() throws Exception {
	}


	
	
	
	
	@Test
	public void test() {
       for(Manager manager:dao.GetAll())
       {
    	   System.out.print(manager.getAadharCardNo()+"\t");
    	   System.out.print(manager.getName()+"\t");
    	   System.out.print(manager.getAddress().getStreetName()+"\t");
    	   System.out.print(manager.getAddress().getCity()+"\t");
    	   System.out.print(manager.getAddress().getState()+"\t");
    	   System.out.print(manager.getEmployeeNo()+"\t");
    	   System.out.print(manager.getProject()+"\t");
    	   System.out.print(manager.getLocation()+"\t");
    	   System.out.print(manager.getNoOfProjetcs()+"\t");
    	   System.out.print(manager.isLeaveApproval()+"\t");
    	   
       }
		
		
		//fail("Not yet implemented");
		/*Manager person=new Manager();
		person.setName("Bala");
		person.setEmployeeNo(43564);
		person.setLeaveApproval(true);
		person.setLocation("Chennai");
		person.setNoOfProjetcs(5);
		person.setProject("HSBC");
		Address address=new Address();
		address.setStreetName("Gandhi Street");
		address.setCity("Chennai");
		address.setState("TamilNadu");
		assertTrue(dao.AddPerson(person, address));*/
		
	}

}
