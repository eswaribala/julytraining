package com.cog.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="New_Payment")
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
/*@DiscriminatorColumn(name="Object_Name",discriminatorType=DiscriminatorType.STRING)
@DiscriminatorValue(value="PaymentObj")*/
public class Payment {
	@Id
	@Column(name="Customer_Id")
	private int customerId;
	@Column(name="Amount")
	private int amount;
	@Temporal(TemporalType.DATE)
	@Column(name="DOT")
	private Date DOT;
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public Date getDOT() {
		return DOT;
	}
	public void setDOT(Date dOT) {
		DOT = dOT;
	}

}
