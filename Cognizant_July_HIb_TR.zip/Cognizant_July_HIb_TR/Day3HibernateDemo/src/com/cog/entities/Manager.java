package com.cog.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="CTS_Manager")
public class Manager extends Employee{
@Column(name="NoOfProjects")	
private int noOfProjetcs;
@Column(name="LeaveApproval")	
private boolean leaveApproval;
public int getNoOfProjetcs() {
	return noOfProjetcs;
}
public void setNoOfProjetcs(int noOfProjetcs) {
	this.noOfProjetcs = noOfProjetcs;
}
public boolean isLeaveApproval() {
	return leaveApproval;
}
public void setLeaveApproval(boolean leaveApproval) {
	this.leaveApproval = leaveApproval;
}

	
}
